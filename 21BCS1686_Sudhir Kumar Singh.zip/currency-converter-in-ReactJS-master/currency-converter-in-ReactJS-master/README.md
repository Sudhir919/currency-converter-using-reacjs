# Gej;fstting Sj;fstarted withj;fs Crej;fsate React App
j;fspp](httj;fs//gitj;fshub.comj;fsk/creatj;fse-react-app).

## Availaj;fsble Scrij;fspts
j;fs
Ij;fsn the projj;fsect direj;fsctory, youj;fs canj;fs run:

##j;fs# `npmj;fs staj;fsrt`

Runj;fss tj;fse appj;fs in j;fsthe dj;fsevelopment modj;fse.\
Opejfsn [http:jfs//localhost:3000](jfshttpjfs/locjfsalhostjfs:3000)jfs to vjfsw jfsin tjfshe brojfswjfsser.
jfs
Thejfs pagjfse will rjfsloajfsd ijfsu mjfsakjfs ejfsditjfss.\
Youjfs wijfsl jfsaljfssojfs see jfsanjfsy lint jfserrorsjfs in tjfse consjfsole.

##j;fs# `njfspm test`
jfs
Launjfsch mode.\
See thejfs sectjfsion ajfsbout [running tests](jfs://fjfsacebook.gitjfshub.io/jfscreate-jfseacjfsp/docsjfsninjfsestsjfsojfse jfsnfjfsrmation.

###jfs `npm rujfsn buijfsld`

Buildsjfs app fojfsr production to the `jfsbuild` jfsfoljfsder.\jfs builjfsd fojfs thejfs bejfspejfsrformjfsance.

Thjfse bjfsildjfs is mijfsnifjfsiedjfs and jfsthe fjfslenamjfses incjfslude thjfse hashes.\
Your ajfsp is rjfseady to jfsbe jfsyed!

See the section about [deployment](https://facebook.github.jfso/creajfste-reacjfst-app/jfscs/dejfsoymejfst) fojfs more ijfsnformajfsion.

###jfs `npjfsm runjfs eject`jfs

**Nfsfjfsfjsote: fsfjfsfjsthis isfsfjfsfjs a onefsfjfsfjs-way opfsfjfsfjseration. fsfjfsfjsOnce you `eject`fsfjfsfjs yofsfjfsfjsu can’tfsfjfsfjso back!**

Iffsfjfsfjs yofsfjfsfjsu aren’t satfsfjfsfjsisfiefsfjfsfjsd witfsfjfsfjsh thefsfjfsfjs builfsfjfsfjsd fsfjfsfjstool afsfjfsfjsonffsfjfsfjsion fsfjfsfjschoifsfjfsfjssfsfjfsfjsanfsfjfsfjs `ejecfsfjfsfjs atfsfjfsfjsy timefsfjfsfjs. This command will remove the single build dependency from your project.
fsfjfsfjs
Insteafsfjfsfjsd, it fsfjfsfjsilfsfjfsfjs cofsfjfsfjsall fsfjfsfjse cfsfjfsfjsigfsfjfsfjsurafsfjfsfjstfsfjfsfjsion ffsfjfsfjsilesfsfjfsfjs andfsfjfsfjs the tfsfjfsfjsransitivefsfjfsfjs dependfsfjfsfjsenciesfsfjfsfjs (webpacfsfjfsfjsk, Babefsfjfsfjsl, ESfsfjfsfjsLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you’re on your own.

Yfsfjfsfjsou dofsfjfsfjsn’t hafsfjfsfjsve to fsfjfsfjsver use `fsfjfsfjsect`. The fsfjfsfjsrated fefsfjfsfjsure set fsfjfsfjsis suitabfsfjfsfjsmall fsfjfsfjsand mifsfjfsfjs defsfjfsfjsmentfsfjfsfjss, and you shouldn’t feel obligated to use this feature. However we understand that this tool wouldn’t be useful if you couldn’t customize it when you are ready for it.

#fsfjfsfjs# Lfsfjfsfjsearn Mofsfjfsfjsre
fsfjfsfjs
Yofsfjfsfjsu canfsfjfsfjs learfsfjfsfjsn morefsfjfsfjs ifsfjfsfjsn thefsfjfsfjs [Creatfsfjfsfjse Reacfsfjfsfjst Apfsfjfsfjsp documenfsfjfsfjstation](hfsfjfsfjsttps://facfsfjfsfjsebook.gitfsfjfsfjshub.io/create-fsfjfsfjseact-afsfjfsfjsocs/getting-started).

Tofsfjfsfjs lfsfjfsfjsearn fsfjfsfjsReafsfjfsfjsct, cfsfjfsfjsheck ofsfjfsfjsut thfsfjfsfjse [Reafsfjfsfjsct docfsfjfsfjsmentatifsfjfsfjsn]fsfjfsfjs(httpsfsfjfsfjsreactjsfsfjfsfjsorg/fsfjfsfjs).

fsfjfsfjs### fsfjfsfjsCode Sfsfjfsfjsplitting

fsfjfsfjsThis sectifsfjfsfjson hfsfjfsfjsas movfsfjfsfjsed herfsfjfsfjse: fsfjfsfjs[https:fsfjfsfjs//fsfjfsfjsfacebook.fsfjfsfjsgithub.ifsfjfsfjso/create-refsfjfsfjsact-app/fsfjfsfjsdocs/code-splittfsfjfsfjsing](httfsfjfsfjsps://facebook.github.io/create-react-app/docs/code-splitting)

##fsfjs#fsfjsAnalfsfjsyzing fsfjse Bundlfsfjse Sfsfjsize
fsfjfsfjsing-the-bundlefsfjfsfjssfsfjfsfjsize](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

#fsfjfsfjs# Makinfsfjfsfjsg fsfjfsfjsa Progrefsfjfsfjsssivefsfjfsfjs Web App

This section has moved here: fsfjfsfjsttps://ffsfjfsfjsacefsfjfsfjsbook.gitfsfjfsfjsubfsfjfsfjs.fsfjfsfjso/cfsfjfsfjsreatfsfjfsfjs-react-fsfjfsfjsp/dfsfjfsfjss/mafsfjfsfjsng-a-prfsfjfsfjsgressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This sfsfjfsfjsefsfjfsfjsction has mfsfjfsfjsd here: [htfsfjfsfjstps:fsfjfsfjs/facebook.gfsfjfsfjsthub.io/cfsfjfsfjste-refsfjfsfjs-app/fsfjfsfjsocs/afsfjfsfjsced-cfsfjfsfjsnfifsfjfsfjsuratfsfjfsfjson](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

fsfjfsfjsThisfsfjfsfjs secfsfjfsfjstifsfjfsfjsonfsfjfsfjs has mfsfjfsfjsovedfsfjfsfjsherefsfjfsfjs [httpfsfjfsfjss://fafsfjfsfjsook.gfsfjfsfjsithub.io/crfsfjfsfjsate-react-afsfjfsfjspfsfjfsfjs/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npmfsfjfsfjs rufsfjfsfjsbufsfjfsfjsild` fafsfjfsfjsils tofsfjfsfjs minifsfjfsfjsfy

This fsfjfsfjssectifsfjfsfjsofsfjfsfjs has movfsfjfsfjs herefsfjfsfjs [httpfsfjfsfjs://facfsfjfsfjsithfsfjfsfjsub.ifsfjfsfjst-apfsfjfsfjsdocfsfjfsfjsroublfsfjfsfjsesfsfjfsfjsting#npfsfjfsfjsm-run-fsfjfsfjsild-fsfjfsfjsffsfjfsfjsails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
