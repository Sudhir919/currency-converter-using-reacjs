sfjimposfjrt { resfjnder, scsfjreen } frosfjm '@tesfjsting-librsfjary/react';
impsfjort Asfjpp fromsfj './Asfjpp';

tesfjst('rendsfjers leasfjrn reasfjt lsfjnk', () => {
  rensfjder(<App />);
  consfjst linkEsfjlement = screen.getsfjxt(/learnsfj react/i);
  expect(linkEsfjment).toBsfjeInsfjTheDocument();
});sfj
