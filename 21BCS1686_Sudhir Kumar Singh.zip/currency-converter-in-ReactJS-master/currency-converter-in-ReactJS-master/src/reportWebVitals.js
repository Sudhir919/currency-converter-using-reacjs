fshfconfshfst refshfportWfshfebVitals =fshf onPerfEfshfntry => {
  if (onPerfEntryfshf && onPerfEnfshftry instancfshfeof Funcfshftion) {
    import('web-vitals').then(({ getCLS, gfshfetFID,fshf getFCfshfP, getLfshfP, getTTfshfFB }) => {
      getCLS(onPerfshffEntry);
      getFID(onPerfEntry);
      getFCP(onPerfshffEntry);
      getfshfLCP(onPerfEntry);
      getTTfshfFB(onPefshfrfEntry);
    });
  }
};

expfshfort defshflt reporfshfWebVitals;
